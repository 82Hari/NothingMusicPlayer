# Nothing Player (Android)

Native Android music player, Nothing OS–style UI (black + red dot-matrix theme),
that scans and plays songs **already on your phone**.

## What it does
- On first launch, asks for permission to read audio on your device
- Scans your device's media library (Music folder, Downloads, WhatsApp media, etc.) using `MediaStore` — no manual file picking needed
- Play / pause / next / previous / seek
- Dot-matrix progress bar + animated dot-ring visualizer (Nothing Phone Glyph style)
- Full track list / queue screen

## How to build

1. Install **Android Studio** (latest stable — "Koala" or newer): https://developer.android.com/studio
2. Open Android Studio → **Open** → select this `NothingMusicPlayer` folder
3. Let Gradle sync (first sync downloads dependencies — needs internet)
4. Connect your phone via USB with **USB debugging** enabled (Settings → Developer Options), or use an emulator
5. Click **Run ▶** — app installs and launches on your device

## First run
- App will ask for music/storage permission — tap **Grant Access**
- It scans your device and lists everything it finds
- Tap any track to play

## Project structure
```
app/src/main/java/com/hari/nothingplayer/
 ├─ MainActivity.kt          → permission flow + entry point
 ├─ PlayerViewModel.kt       → ExoPlayer playback logic & state
 ├─ Song.kt                  → data model + MediaStore scanner
 └─ ui/
     ├─ Theme.kt             → color tokens (black/red palette)
     └─ PlayerScreen.kt      → all Compose UI (now playing + queue)
```

## Notes
- Min Android version supported: **Android 8.0 (API 26)**
- Uses Jetpack Compose + Media3 ExoPlayer (Google's modern audio playback library)
- Only reads audio that's already legally on your device — no download/scraping functionality, by design
- To change the accent color, edit `NRed` in `ui/Theme.kt`
- To change app name, edit `strings.xml` → `app_name`
