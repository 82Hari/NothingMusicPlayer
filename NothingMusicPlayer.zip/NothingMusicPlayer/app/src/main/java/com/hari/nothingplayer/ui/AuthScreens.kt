package com.hari.nothingplayer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private enum class AuthScreen { WELCOME_BACK, SIGN_UP, FORGET_PASSWORD }

/**
 * The whole dummy auth flow. This app has no accounts or server — there's
 * nowhere for these fields to go — so every button here just does a light
 * non-empty check and calls [onComplete]. It exists purely to match a
 * requested login/sign-up/forgot-password UI look before landing in the
 * real (local-library) app.
 */
@Composable
fun AuthFlow(onComplete: () -> Unit) {
    var screen by remember { mutableStateOf(AuthScreen.WELCOME_BACK) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NBackgroundBrush)
            .padding(horizontal = 28.dp)
    ) {
        when (screen) {
            AuthScreen.WELCOME_BACK -> WelcomeBackScreen(
                onLogIn = onComplete,
                onGoToSignUp = { screen = AuthScreen.SIGN_UP },
                onForgotPassword = { screen = AuthScreen.FORGET_PASSWORD }
            )
            AuthScreen.SIGN_UP -> SignUpScreen(
                onSignUp = onComplete,
                onGoToLogIn = { screen = AuthScreen.WELCOME_BACK }
            )
            AuthScreen.FORGET_PASSWORD -> ForgetPasswordScreen(
                onSendReset = { screen = AuthScreen.WELCOME_BACK },
                onGoToLogIn = { screen = AuthScreen.WELCOME_BACK }
            )
        }
    }
}

@Composable
private fun WelcomeBackScreen(
    onLogIn: () -> Unit,
    onGoToSignUp: () -> Unit,
    onForgotPassword: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Welcome Back!", color = NText, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("Login to continue to our app", color = NTextDim, fontSize = 13.sp)
        Spacer(Modifier.height(28.dp))

        AuthTextField(icon = Icons.Default.Email, placeholder = "Email Address", value = email, onValueChange = { email = it })
        Spacer(Modifier.height(12.dp))
        AuthTextField(icon = Icons.Default.Lock, placeholder = "Password", value = password, onValueChange = { password = it }, isPassword = true)

        Spacer(Modifier.height(10.dp))
        Text(
            "Forgot password?",
            color = NRed,
            fontSize = 12.sp,
            modifier = Modifier.align(Alignment.End).clickable { onForgotPassword() }
        )

        Spacer(Modifier.height(20.dp))
        AuthGradientButton(text = "Log In", onClick = onLogIn)

        Spacer(Modifier.height(24.dp))
        AuthFooterLink(
            plain = "Don't have an account? ",
            link = "Sign up",
            onClick = onGoToSignUp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
private fun SignUpScreen(
    onSignUp: () -> Unit,
    onGoToLogIn: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Sign Up", color = NText, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("Sign Up and Start Listening", color = NTextDim, fontSize = 13.sp)
        Spacer(Modifier.height(28.dp))

        AuthTextField(icon = Icons.Default.Person, placeholder = "Your Name", value = name, onValueChange = { name = it })
        Spacer(Modifier.height(12.dp))
        AuthTextField(icon = Icons.Default.Email, placeholder = "Email Address", value = email, onValueChange = { email = it })
        Spacer(Modifier.height(12.dp))
        AuthTextField(icon = Icons.Default.Lock, placeholder = "Password", value = password, onValueChange = { password = it }, isPassword = true)

        Spacer(Modifier.height(24.dp))
        AuthGradientButton(text = "Sign up", onClick = onSignUp)

        Spacer(Modifier.height(24.dp))
        AuthFooterLink(
            plain = "Already have an account? ",
            link = "Log in",
            onClick = onGoToLogIn,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
private fun ForgetPasswordScreen(
    onSendReset: () -> Unit,
    onGoToLogIn: () -> Unit
) {
    var email by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Forget Password", color = NText, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text(
            "Enter your email address below. We will send you a password reset email.",
            color = NTextDim,
            fontSize = 13.sp
        )
        Spacer(Modifier.height(24.dp))

        AuthTextField(icon = Icons.Default.Email, placeholder = "Email Address", value = email, onValueChange = { email = it })

        Spacer(Modifier.height(24.dp))
        AuthGradientButton(text = "Send Password Reset", onClick = onSendReset)

        Spacer(Modifier.height(24.dp))
        AuthFooterLink(
            plain = "Already have an account? ",
            link = "Log in",
            onClick = onGoToLogIn,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
private fun AuthTextField(
    icon: ImageVector,
    placeholder: String,
    value: String,
    onValueChange: (String) -> Unit,
    isPassword: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(NSurface)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = NTextDim, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Box(modifier = Modifier.weight(1f)) {
            if (value.isEmpty()) {
                Text(placeholder, color = NTextDim, fontSize = 13.sp)
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                textStyle = TextStyle(color = NText, fontSize = 13.sp),
                cursorBrush = SolidColor(NRed),
                visualTransformation = if (isPassword) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun AuthGradientButton(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(NAccentBrush)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = NBlack, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun AuthFooterLink(plain: String, link: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(modifier = modifier) {
        Text(plain, color = NTextDim, fontSize = 12.sp, textAlign = TextAlign.Center)
        Text(link, color = NRed, fontSize = 12.sp, modifier = Modifier.clickable(onClick = onClick))
    }
}
