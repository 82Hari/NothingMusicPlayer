package com.hari.nothingplayer.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor

enum class AppTheme(val displayName: String, val tagline: String) {
    NOTHING("Nothing", "Black, red dot-matrix look"),
    APPLE_GLASS("Apple Glass", "Light frosted glass"),
    SUNSET_BLAZE("Sunset Blaze", "Warm orange to pink"),
    OCEAN_BREEZE("Ocean Breeze", "Deep blue to teal"),
    MIDNIGHT_PURPLE("Midnight Purple", "Indigo to violet"),
    CYBERPUNK_NEON("Cyberpunk Neon", "Black, magenta, cyan"),
    FOREST_MIST("Forest Mist", "Fresh green tones"),
    ROSE_GOLD("Rose Gold", "Soft pink to peach"),
    AURORA("Aurora", "Teal, green, blue glow"),
    GOLDEN_HOUR("Golden Hour", "Amber to warm gold"),
    BERRY_PUNCH("Berry Punch", "Magenta to deep purple"),
    ARCTIC_FROST("Arctic Frost", "Icy blue to white")
}

/** Full palette + styling flags for a theme. */
data class AppColors(
    val background: Color,
    val backgroundBrush: Brush?,
    val surface: Color,
    val hairline: Color,
    val hairlineDim: Color,
    val accent: Color,
    val text: Color,
    val textDim: Color,
    val isGlass: Boolean
)

private fun gradient(vararg colors: Color): Brush = Brush.verticalGradient(colors.toList())

// Light-background glass themes read best with dark text and a fairly opaque white card.
private fun lightGlass(bg: List<Color>, accent: Color, text: Color, textDim: Color) = AppColors(
    background = bg.first(),
    backgroundBrush = gradient(*bg.toTypedArray()),
    surface = Color(0xCCFFFFFF),
    hairline = Color(0x66FFFFFF),
    hairlineDim = Color(0x33FFFFFF),
    accent = accent,
    text = text,
    textDim = textDim,
    isGlass = true
)

// Dark-background glass themes read best with light text and a smoky, low-alpha card.
private fun darkGlass(bg: List<Color>, accent: Color, text: Color, textDim: Color) = AppColors(
    background = bg.first(),
    backgroundBrush = gradient(*bg.toTypedArray()),
    surface = Color(0x26FFFFFF),
    hairline = Color(0x40FFFFFF),
    hairlineDim = Color(0x20FFFFFF),
    accent = accent,
    text = text,
    textDim = textDim,
    isGlass = true
)

private val NothingColors = AppColors(
    background = Color(0xFF000000),
    backgroundBrush = null,
    surface = Color(0xFF0D0D0D),
    hairline = Color(0xFF262626),
    hairlineDim = Color(0xFF1A1A1A),
    accent = Color(0xFFD71921),
    text = Color(0xFFF5F5F0),
    textDim = Color(0xFF6B6B66),
    isGlass = false
)

private val AppleGlassColors = lightGlass(
    bg = listOf(Color(0xFFDCE6F7), Color(0xFFEFE6F5), Color(0xFFE3F0F7)),
    accent = Color(0xFF0A84FF),
    text = Color(0xFF1C1C1E),
    textDim = Color(0xFF6E6E73)
)

private val SunsetBlazeColors = lightGlass(
    bg = listOf(Color(0xFFFF7E5F), Color(0xFFFEB47B), Color(0xFFFFD26F)),
    accent = Color(0xFFE63946),
    text = Color(0xFF2B1B12),
    textDim = Color(0xFF7A5C4E)
)

private val OceanBreezeColors = darkGlass(
    bg = listOf(Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364)),
    accent = Color(0xFF00E5FF),
    text = Color(0xFFF5F5F0),
    textDim = Color(0xFF9FB8C4)
)

private val MidnightPurpleColors = darkGlass(
    bg = listOf(Color(0xFF0F0C29), Color(0xFF302B63), Color(0xFF24243E)),
    accent = Color(0xFFBB86FC),
    text = Color(0xFFF1E9FF),
    textDim = Color(0xFF9E8FC7)
)

private val CyberpunkNeonColors = darkGlass(
    bg = listOf(Color(0xFF000000), Color(0xFF0D0221), Color(0xFF190061)),
    accent = Color(0xFF00FFF0),
    text = Color(0xFFF5F5F0),
    textDim = Color(0xFF8A7CA8)
)

private val ForestMistColors = lightGlass(
    bg = listOf(Color(0xFFD4FC79), Color(0xFF96E6A1), Color(0xFF6DD5ED)),
    accent = Color(0xFF1B998B),
    text = Color(0xFF15291F),
    textDim = Color(0xFF4F6E5D)
)

private val RoseGoldColors = lightGlass(
    bg = listOf(Color(0xFFFFDDE1), Color(0xFFEE9CA7), Color(0xFFFFDDE1)),
    accent = Color(0xFFB76E79),
    text = Color(0xFF3D2327),
    textDim = Color(0xFF8C6B6F)
)

private val AuroraColors = darkGlass(
    bg = listOf(Color(0xFF000428), Color(0xFF004E92), Color(0xFF43CEA2)),
    accent = Color(0xFF7CFFCB),
    text = Color(0xFFF0FFFA),
    textDim = Color(0xFF9FD8C9)
)

private val GoldenHourColors = lightGlass(
    bg = listOf(Color(0xFFFFECB3), Color(0xFFFFD54F), Color(0xFFFF9E52)),
    accent = Color(0xFFB8590A),
    text = Color(0xFF3A2607),
    textDim = Color(0xFF8A6E42)
)

private val BerryPunchColors = darkGlass(
    bg = listOf(Color(0xFF3A0CA3), Color(0xFF7209B7), Color(0xFFC9184A)),
    accent = Color(0xFFFF4D9D),
    text = Color(0xFFFAF0FF),
    textDim = Color(0xFFCBA3D8)
)

private val ArcticFrostColors = lightGlass(
    bg = listOf(Color(0xFFE0F7FA), Color(0xFFB3E5FC), Color(0xFFFFFFFF)),
    accent = Color(0xFF0288D1),
    text = Color(0xFF102A38),
    textDim = Color(0xFF5C7A8A)
)

fun colorsFor(theme: AppTheme): AppColors = when (theme) {
    AppTheme.NOTHING -> NothingColors
    AppTheme.APPLE_GLASS -> AppleGlassColors
    AppTheme.SUNSET_BLAZE -> SunsetBlazeColors
    AppTheme.OCEAN_BREEZE -> OceanBreezeColors
    AppTheme.MIDNIGHT_PURPLE -> MidnightPurpleColors
    AppTheme.CYBERPUNK_NEON -> CyberpunkNeonColors
    AppTheme.FOREST_MIST -> ForestMistColors
    AppTheme.ROSE_GOLD -> RoseGoldColors
    AppTheme.AURORA -> AuroraColors
    AppTheme.GOLDEN_HOUR -> GoldenHourColors
    AppTheme.BERRY_PUNCH -> BerryPunchColors
    AppTheme.ARCTIC_FROST -> ArcticFrostColors
}

val LocalAppColors = staticCompositionLocalOf { NothingColors }

// ---- Backward-compatible accessors ----
// Every screen composable already references these names directly (NBlack, NRed, ...).
// Turning them into composable getters that read the current theme means the whole
// UI re-themes itself without editing each call site.
val NBlack: Color @Composable get() = LocalAppColors.current.background
val NSurface: Color @Composable get() = LocalAppColors.current.surface
val NHairline: Color @Composable get() = LocalAppColors.current.hairline
val NHairlineDim: Color @Composable get() = LocalAppColors.current.hairlineDim
val NRed: Color @Composable get() = LocalAppColors.current.accent
val NText: Color @Composable get() = LocalAppColors.current.text
val NTextDim: Color @Composable get() = LocalAppColors.current.textDim
val NIsGlass: Boolean @Composable get() = LocalAppColors.current.isGlass

/** Solid color for flat themes, soft gradient for glass themes. */
val NBackgroundBrush: Brush @Composable get() =
    LocalAppColors.current.backgroundBrush ?: SolidColor(LocalAppColors.current.background)
