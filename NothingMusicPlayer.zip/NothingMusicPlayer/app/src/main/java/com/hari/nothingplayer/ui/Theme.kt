package com.hari.nothingplayer.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor

enum class AppTheme(val displayName: String) {
    NOTHING("Nothing"),
    APPLE_GLASS("Apple Glass")
}

/** Full palette + styling flags for a theme. */
data class AppColors(
    val background: Color,
    val backgroundBrush: Brush?,
    val surface: Color,
    val hairline: Color,
    val hairlineDim: Color,
    val accent: Color,
    val text: Color,
    val textDim: Color,
    val isGlass: Boolean
)

// ---- Nothing OS inspired palette (original theme) ----
private val NothingColors = AppColors(
    background = Color(0xFF000000),
    backgroundBrush = null,
    surface = Color(0xFF0D0D0D),
    hairline = Color(0xFF262626),
    hairlineDim = Color(0xFF1A1A1A),
    accent = Color(0xFFD71921),
    text = Color(0xFFF5F5F0),
    textDim = Color(0xFF6B6B66),
    isGlass = false
)

// ---- Apple-style frosted glass palette ----
private val AppleGlassColors = AppColors(
    background = Color(0xFFE8ECF5),
    backgroundBrush = Brush.verticalGradient(
        listOf(
            Color(0xFFDCE6F7),
            Color(0xFFEFE6F5),
            Color(0xFFE3F0F7)
        )
    ),
    surface = Color(0xB3FFFFFF),      // translucent white "glass" card
    hairline = Color(0x59FFFFFF),     // soft white edge highlight
    hairlineDim = Color(0x26FFFFFF),
    accent = Color(0xFF0A84FF),       // iOS system blue
    text = Color(0xFF1C1C1E),
    textDim = Color(0xFF6E6E73),
    isGlass = true
)

fun colorsFor(theme: AppTheme): AppColors = when (theme) {
    AppTheme.NOTHING -> NothingColors
    AppTheme.APPLE_GLASS -> AppleGlassColors
}

val LocalAppColors = staticCompositionLocalOf { NothingColors }

// ---- Backward-compatible accessors ----
// Every screen composable already references these names directly (NBlack, NRed, ...).
// Turning them into composable getters that read the current theme means the whole
// UI re-themes itself without editing each call site.
val NBlack: Color @Composable get() = LocalAppColors.current.background
val NSurface: Color @Composable get() = LocalAppColors.current.surface
val NHairline: Color @Composable get() = LocalAppColors.current.hairline
val NHairlineDim: Color @Composable get() = LocalAppColors.current.hairlineDim
val NRed: Color @Composable get() = LocalAppColors.current.accent
val NText: Color @Composable get() = LocalAppColors.current.text
val NTextDim: Color @Composable get() = LocalAppColors.current.textDim
val NIsGlass: Boolean @Composable get() = LocalAppColors.current.isGlass

/** Solid color for flat themes, soft gradient for glass themes. */
val NBackgroundBrush: Brush @Composable get() =
    LocalAppColors.current.backgroundBrush ?: SolidColor(LocalAppColors.current.background)
