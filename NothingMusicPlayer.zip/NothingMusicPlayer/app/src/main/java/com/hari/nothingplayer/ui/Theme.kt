package com.hari.nothingplayer.ui

import androidx.compose.ui.graphics.Color

// Nothing OS inspired palette
val NBlack = Color(0xFF000000)
val NSurface = Color(0xFF0D0D0D)
val NHairline = Color(0xFF262626)
val NHairlineDim = Color(0xFF1A1A1A)
val NRed = Color(0xFFD71921)
val NText = Color(0xFFF5F5F0)
val NTextDim = Color(0xFF6B6B66)
