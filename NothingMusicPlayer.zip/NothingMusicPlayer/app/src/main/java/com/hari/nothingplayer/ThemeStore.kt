package com.hari.nothingplayer

import android.content.Context
import com.hari.nothingplayer.ui.AppTheme

object ThemeStore {
    private const val PREFS = "nothing_player_settings"
    private const val KEY = "app_theme"

    fun load(context: Context): AppTheme {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val name = prefs.getString(KEY, AppTheme.NOTHING.name)
        return try {
            AppTheme.valueOf(name ?: AppTheme.NOTHING.name)
        } catch (e: IllegalArgumentException) {
            AppTheme.NOTHING
        }
    }

    fun save(context: Context, theme: AppTheme) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY, theme.name).apply()
    }
}
