package com.hari.nothingplayer

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import kotlin.math.roundToInt

data class AudioOutputInfo(
    val label: String,
    val isBluetooth: Boolean
)

/**
 * Reads the current music stream volume and figures out whether audio is
 * routing to the built-in speaker, a wired headset, or a Bluetooth device.
 * There's no public API that guarantees "this exact device is active", so we
 * use the presence of a connected Bluetooth/wired output as the signal —
 * Android automatically routes music there over the speaker once connected.
 */
object AudioOutputHelper {

    private fun audioManager(context: Context): AudioManager =
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun currentOutput(context: Context): AudioOutputInfo {
        val am = audioManager(context)
        val devices = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)

        val bluetooth = devices.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
        }
        if (bluetooth != null) {
            val name = bluetooth.productName?.toString()?.trim().takeUnless { it.isNullOrBlank() }
            return AudioOutputInfo(label = name ?: "Bluetooth", isBluetooth = true)
        }

        val wired = devices.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET || it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES
        }
        if (wired != null) {
            return AudioOutputInfo(label = "Headphones", isBluetooth = false)
        }

        return AudioOutputInfo(label = "Speaker", isBluetooth = false)
    }

    fun volumePercent(context: Context): Int {
        val am = audioManager(context)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        if (max <= 0) return 0
        return ((cur.toFloat() / max) * 100f).roundToInt().coerceIn(0, 100)
    }

    fun setVolumePercent(context: Context, percent: Int) {
        val am = audioManager(context)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val target = ((percent.coerceIn(0, 100) / 100f) * max).roundToInt().coerceIn(0, max)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
    }
}
