package com.hari.nothingplayer

import android.content.Context
import android.media.AudioManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import android.os.Build

data class EqBand(
    val index: Int,
    val freqHz: Int,
    val levelMillibel: Int
)

data class SpatialAudioStatus(
    // Whether this Android version even exposes the Spatializer API (12L / API 32+).
    val apiSupported: Boolean = false,
    // Whether the current output device + content are capable of spatial audio right now.
    val available: Boolean = false,
    // Whether spatialization is actively being applied to this app's audio right now.
    val enabled: Boolean = false,
    // Spatializer.SPATIALIZER_IMMERSIVE_LEVEL_* — 0 = none, higher = richer (e.g. multichannel/object-based).
    val immersiveLevel: Int = 0
)

data class AudioEffectsUiState(
    // False until an audio session id has been bound (i.e. the service has created a player).
    val ready: Boolean = false,
    val effectsEnabled: Boolean = true,

    val eqSupported: Boolean = false,
    val eqPresets: List<String> = emptyList(),
    val eqPresetIndex: Int = -1, // -1 = custom / manually adjusted
    val eqBands: List<EqBand> = emptyList(),
    val eqLevelRangeMb: IntRange = 0..0,

    val bassBoostSupported: Boolean = false,
    val bassBoostStrength: Int = 0, // 0-1000

    val virtualizerSupported: Boolean = false,
    val virtualizerStrength: Int = 0, // 0-1000

    val loudnessSupported: Boolean = false,
    val loudnessGainMb: Int = 0, // 0-2000 (0-20dB), LoudnessEnhancer has no fixed upper bound but we cap the UI

    val spatialAudio: SpatialAudioStatus = SpatialAudioStatus()
)

/**
 * Owns the actual Android platform audio effects for one audio session.
 * Effects are session-scoped: whenever [AudioSessionHolder] reports a new
 * session id (new playback service instance, or the very first session
 * ExoPlayer allocates) the caller should [release] the old controller and
 * create a fresh one for the new id — settings are re-applied from
 * [AudioEffectsStore] each time so they carry over even though the
 * underlying effect objects are new.
 *
 * Individual effects are optional: not every device/DSP exposes all four,
 * so each is wrapped in its own try/catch and just reports itself as
 * unsupported rather than crashing playback.
 */
class AudioEffectsController(
    private val context: Context,
    private val sessionId: Int
) {
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null

    /** Builds the effect chain and applies any previously saved settings. Call once. */
    fun bind(): AudioEffectsUiState {
        val enabled = AudioEffectsStore.isEnabled(context)

        var eqState = AudioEffectsUiState()
        try {
            val eq = Equalizer(0, sessionId)
            equalizer = eq
            eq.setEnabled(enabled)

            val presets = (0 until eq.numberOfPresets.toInt()).map { eq.getPresetName(it.toShort()) }
            val range = eq.bandLevelRange
            val savedLevels = AudioEffectsStore.eqBandLevels(context)
            val savedPreset = AudioEffectsStore.eqPreset(context)

            if (savedPreset >= 0 && savedPreset < presets.size) {
                eq.usePreset(savedPreset.toShort())
            } else if (savedLevels != null && savedLevels.size == eq.numberOfBands.toInt()) {
                savedLevels.forEachIndexed { i, level ->
                    eq.setBandLevel(i.toShort(), level.toShort())
                }
            }

            val bands = (0 until eq.numberOfBands.toInt()).map { i ->
                EqBand(
                    index = i,
                    freqHz = eq.getCenterFreq(i.toShort()) / 1000,
                    levelMillibel = eq.getBandLevel(i.toShort()).toInt()
                )
            }

            eqState = AudioEffectsUiState(
                eqSupported = true,
                eqPresets = presets,
                eqPresetIndex = if (savedPreset in presets.indices) savedPreset else -1,
                eqBands = bands,
                eqLevelRangeMb = range[0].toInt()..range[1].toInt()
            )
        } catch (e: Exception) {
            equalizer = null
        }

        var bassSupported = false
        var bassStrength = 0
        try {
            val bb = BassBoost(0, sessionId)
            bassBoost = bb
            bassSupported = bb.strengthSupported
            bb.setEnabled(enabled)
            bassStrength = AudioEffectsStore.bassBoostStrength(context).coerceIn(0, 1000)
            if (bassSupported) bb.setStrength(bassStrength.toShort())
        } catch (e: Exception) {
            bassBoost = null
        }

        var virtSupported = false
        var virtStrength = 0
        try {
            val v = Virtualizer(0, sessionId)
            virtualizer = v
            virtSupported = v.strengthSupported
            v.setEnabled(enabled)
            virtStrength = AudioEffectsStore.virtualizerStrength(context).coerceIn(0, 1000)
            if (virtSupported) v.setStrength(virtStrength.toShort())
        } catch (e: Exception) {
            virtualizer = null
        }

        var loudnessSupported = false
        var loudnessGain = 0
        try {
            val le = LoudnessEnhancer(sessionId)
            loudnessEnhancer = le
            loudnessSupported = true
            loudnessGain = AudioEffectsStore.loudnessGainMb(context).coerceIn(0, 2000)
            le.setTargetGain(loudnessGain)
            le.setEnabled(enabled)
        } catch (e: Exception) {
            loudnessEnhancer = null
        }

        return eqState.copy(
            ready = true,
            effectsEnabled = enabled,
            bassBoostSupported = bassSupported,
            bassBoostStrength = bassStrength,
            virtualizerSupported = virtSupported,
            virtualizerStrength = virtStrength,
            loudnessSupported = loudnessSupported,
            loudnessGainMb = loudnessGain
        )
    }

    fun setMasterEnabled(enabled: Boolean) {
        AudioEffectsStore.setEnabled(context, enabled)
        equalizer?.setEnabled(enabled)
        bassBoost?.setEnabled(enabled)
        virtualizer?.setEnabled(enabled)
        loudnessEnhancer?.setEnabled(enabled)
    }

    /** Applies a built-in preset (e.g. "Rock", "Jazz") and reports the resulting band levels. */
    fun setPreset(presetIndex: Int): List<EqBand> {
        val eq = equalizer ?: return emptyList()
        eq.usePreset(presetIndex.toShort())
        AudioEffectsStore.setEqPreset(context, presetIndex)
        AudioEffectsStore.setEqBandLevels(context, (0 until eq.numberOfBands.toInt()).map { eq.getBandLevel(it.toShort()).toInt() })
        return (0 until eq.numberOfBands.toInt()).map { i ->
            EqBand(i, eq.getCenterFreq(i.toShort()) / 1000, eq.getBandLevel(i.toShort()).toInt())
        }
    }

    /** Manually dragging a band switches the preset to "custom" (-1). */
    fun setBandLevel(bandIndex: Int, levelMb: Int) {
        val eq = equalizer ?: return
        eq.setBandLevel(bandIndex.toShort(), levelMb.toShort())
        AudioEffectsStore.setEqPreset(context, -1)
        AudioEffectsStore.setEqBandLevels(context, (0 until eq.numberOfBands.toInt()).map { eq.getBandLevel(it.toShort()).toInt() })
    }

    fun setBassBoost(strength: Int) {
        val bb = bassBoost ?: return
        val clamped = strength.coerceIn(0, 1000)
        bb.setStrength(clamped.toShort())
        AudioEffectsStore.setBassBoostStrength(context, clamped)
    }

    fun setVirtualizer(strength: Int) {
        val v = virtualizer ?: return
        val clamped = strength.coerceIn(0, 1000)
        v.setStrength(clamped.toShort())
        AudioEffectsStore.setVirtualizerStrength(context, clamped)
    }

    fun setLoudness(gainMb: Int) {
        val le = loudnessEnhancer ?: return
        val clamped = gainMb.coerceIn(0, 2000)
        le.setTargetGain(clamped)
        AudioEffectsStore.setLoudnessGainMb(context, clamped)
    }

    fun release() {
        try { equalizer?.release() } catch (e: Exception) { /* ignore */ }
        try { bassBoost?.release() } catch (e: Exception) { /* ignore */ }
        try { virtualizer?.release() } catch (e: Exception) { /* ignore */ }
        try { loudnessEnhancer?.release() } catch (e: Exception) { /* ignore */ }
        equalizer = null
        bassBoost = null
        virtualizer = null
        loudnessEnhancer = null
    }

    companion object {
        /**
         * Reads the real, honest Spatial Audio status from the platform.
         *
         * IMPORTANT LIMITATION: Android has no public API that lets a third-party
         * app enable or control Dolby Atmos specifically — Atmos is a proprietary
         * OEM/DSP feature baked into the phone's audio path, not something apps
         * can switch on. What Android *does* expose (API 32+) is the generic
         * android.media.Spatializer, which reports whether the OS + connected
         * output device currently supports spatial/immersive audio rendering,
         * and whether it's actively being applied — regardless of which specific
         * technology (Atmos, Sony 360, DTS:X, etc.) the OEM uses under the hood.
         * That's what this reads and reports. On devices/Android versions where
         * this API doesn't exist, we say so rather than guessing.
         */
        fun readSpatialAudioStatus(context: Context): SpatialAudioStatus {
            if (Build.VERSION.SDK_INT < 32) {
                return SpatialAudioStatus(apiSupported = false)
            }
            return try {
                val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val spatializer = am.spatializer
                SpatialAudioStatus(
                    apiSupported = true,
                    available = spatializer.isAvailable,
                    enabled = spatializer.isEnabled,
                    immersiveLevel = spatializer.immersiveAudioLevel
                )
            } catch (e: Exception) {
                SpatialAudioStatus(apiSupported = false)
            }
        }
    }
}
