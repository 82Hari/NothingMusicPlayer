package com.hari.nothingplayer

import android.content.Context

object FavoritesStore {
    private const val PREFS = "nothing_player_favorites"
    private const val KEY = "favorite_ids"

    fun load(context: Context): Set<Long> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getStringSet(KEY, emptySet())
            ?.mapNotNull { it.toLongOrNull() }
            ?.toSet() ?: emptySet()
    }

    fun save(context: Context, ids: Set<Long>) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putStringSet(KEY, ids.map { it.toString() }.toSet()).apply()
    }
}
