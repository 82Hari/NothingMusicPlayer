package com.hari.nothingplayer

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadataRetriever
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// repeatMode: 0 = off, 1 = repeat all, 2 = repeat one
data class PlayerUiState(
    val songs: List<Song> = emptyList(),
    val currentIndex: Int = -1,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val permissionGranted: Boolean = false,
    val shuffleOn: Boolean = false,
    val repeatMode: Int = 0,
    val favorites: Set<Long> = emptySet(),
    val searchQuery: String = "",
    val favoritesOnly: Boolean = false,
    val recentOnly: Boolean = false,
    val recentlyPlayed: List<Long> = emptyList(),
    val playlists: Map<String, List<Long>> = emptyMap(),
    val sleepTimerEndAt: Long? = null,
    val loadingArtwork: Boolean = false
)

class PlayerViewModel(application: Application) : AndroidViewModel(application) {

    private var controller: MediaController? = null
    private var songsLoaded = false
    private var sleepTimerJob: Job? = null

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _uiState.value = _uiState.value.copy(isPlaying = isPlaying)
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val idx = _uiState.value.songs.indexOfFirst { it.uri.toString() == mediaItem?.mediaId }
            if (idx >= 0) {
                _uiState.value = _uiState.value.copy(currentIndex = idx)
                val song = _uiState.value.songs[idx]
                PlaybackStateStore.addRecentlyPlayed(getApplication(), song.id)
                _uiState.value = _uiState.value.copy(
                    recentlyPlayed = PlaybackStateStore.getRecentlyPlayed(getApplication())
                )
            }
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            _uiState.value = _uiState.value.copy(shuffleOn = shuffleModeEnabled)
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            val mapped = when (repeatMode) {
                Player.REPEAT_MODE_ALL -> 1
                Player.REPEAT_MODE_ONE -> 2
                else -> 0
            }
            _uiState.value = _uiState.value.copy(repeatMode = mapped)
        }
    }

    init {
        val app: Application = application
        val sessionToken = SessionToken(app, ComponentName(app, MusicPlaybackService::class.java))
        val controllerFuture = MediaController.Builder(app, sessionToken).buildAsync()
        controllerFuture.addListener({
            controller = controllerFuture.get()
            controller?.addListener(playerListener)
            controller?.let { c ->
                if (c.mediaItemCount > 0) {
                    _uiState.value = _uiState.value.copy(
                        isPlaying = c.isPlaying,
                        shuffleOn = c.shuffleModeEnabled
                    )
                }
            }
        }, MoreExecutors.directExecutor())

        // Poll playback position for the progress bar, and persist resume state
        viewModelScope.launch {
            while (true) {
                val c = controller
                if (c != null) {
                    _uiState.value = _uiState.value.copy(
                        positionMs = c.currentPosition.coerceAtLeast(0),
                        durationMs = c.duration.coerceAtLeast(0)
                    )
                    val idx = _uiState.value.currentIndex
                    val song = _uiState.value.songs.getOrNull(idx)
                    if (song != null && c.currentPosition > 0) {
                        PlaybackStateStore.saveLastPlayed(getApplication(), song.id, c.currentPosition)
                    }
                }
                delay(1000)
            }
        }

        _uiState.value = _uiState.value.copy(
            favorites = FavoritesStore.load(application),
            recentlyPlayed = PlaybackStateStore.getRecentlyPlayed(application),
            playlists = PlaybackStateStore.getPlaylists(application)
        )
    }

    fun onPermissionGranted() {
        if (songsLoaded) return
        songsLoaded = true
        val songs = SongScanner.scanDevice(getApplication())
        _uiState.value = _uiState.value.copy(songs = songs, permissionGranted = true)
        setupQueueWhenReady(songs)
    }

    private fun setupQueueWhenReady(songs: List<Song>) {
        val c = controller
        if (c == null) {
            viewModelScope.launch {
                delay(150)
                setupQueueWhenReady(songs)
            }
            return
        }

        if (c.mediaItemCount > 0) {
            // The background service already has a live queue (app was reopened
            // while music kept playing) — don't reset it, just reflect its state.
            val currentId = c.currentMediaItem?.mediaId
            val idx = songs.indexOfFirst { it.uri.toString() == currentId }
            _uiState.value = _uiState.value.copy(
                currentIndex = idx,
                isPlaying = c.isPlaying
            )
            return
        }

        _uiState.value = _uiState.value.copy(loadingArtwork = true)

        viewModelScope.launch(Dispatchers.IO) {
            val context: Context = getApplication()
            val mediaItems = songs.map { song ->
                val embeddedArt = extractEmbeddedArt(context, song)
                val metadataBuilder = MediaMetadata.Builder()
                    .setTitle(song.title)
                    .setArtist(song.artist)
                if (embeddedArt != null) {
                    metadataBuilder.setArtworkData(embeddedArt, MediaMetadata.PICTURE_TYPE_FRONT_COVER)
                } else if (song.artworkUri != null) {
                    metadataBuilder.setArtworkUri(song.artworkUri)
                }
                MediaItem.Builder()
                    .setMediaId(song.uri.toString())
                    .setUri(song.uri)
                    .setMediaMetadata(metadataBuilder.build())
                    .build()
            }

            withContext(Dispatchers.Main) {
                c.setMediaItems(mediaItems)
                c.prepare()
                _uiState.value = _uiState.value.copy(loadingArtwork = false)

                val last = PlaybackStateStore.loadLastPlayed(getApplication())
                if (last != null) {
                    val (lastSongId, lastPosition) = last
                    val idx = songs.indexOfFirst { it.id == lastSongId }
                    if (idx >= 0) {
                        c.seekTo(idx, lastPosition)
                        _uiState.value = _uiState.value.copy(currentIndex = idx)
                    }
                }
            }
        }
    }

    /** Reads the cover art embedded directly in the audio file (ID3/etc), which is
     *  far more reliable than the deprecated MediaStore album-art table. */
    private fun extractEmbeddedArt(context: Context, song: Song): ByteArray? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, song.uri)
            retriever.embeddedPicture
        } catch (e: Exception) {
            null
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    fun playAt(index: Int) {
        controller?.seekTo(index, 0)
        controller?.play()
        _uiState.value = _uiState.value.copy(currentIndex = index)
    }

    fun togglePlayPause() {
        val c = controller ?: return
        if (_uiState.value.currentIndex == -1) {
            if (_uiState.value.songs.isNotEmpty()) playAt(0)
            return
        }
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() {
        controller?.seekToNextMediaItem()
    }

    fun previous() {
        val c = controller ?: return
        if (c.currentPosition > 3000) {
            c.seekTo(0)
        } else {
            c.seekToPreviousMediaItem()
        }
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    fun cycleRepeatMode() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun toggleFavorite(songId: Long) {
        val current = _uiState.value.favorites
        val updated = if (current.contains(songId)) current - songId else current + songId
        _uiState.value = _uiState.value.copy(favorites = updated)
        FavoritesStore.save(getApplication(), updated)
    }

    fun setSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun toggleFavoritesOnly() {
        _uiState.value = _uiState.value.copy(
            favoritesOnly = !_uiState.value.favoritesOnly,
            recentOnly = false
        )
    }

    fun toggleRecentOnly() {
        _uiState.value = _uiState.value.copy(
            recentOnly = !_uiState.value.recentOnly,
            favoritesOnly = false
        )
    }

    // --- Sleep timer ---
    fun startSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        val endAt = System.currentTimeMillis() + minutes * 60_000L
        _uiState.value = _uiState.value.copy(sleepTimerEndAt = endAt)
        sleepTimerJob = viewModelScope.launch {
            delay(minutes * 60_000L)
            controller?.pause()
            _uiState.value = _uiState.value.copy(sleepTimerEndAt = null)
        }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        _uiState.value = _uiState.value.copy(sleepTimerEndAt = null)
    }

    // --- Playlists ---
    fun createPlaylist(name: String) {
        if (name.isBlank()) return
        val updated = PlaybackStateStore.createPlaylist(getApplication(), name.trim())
        _uiState.value = _uiState.value.copy(playlists = updated)
    }

    fun deletePlaylist(name: String) {
        val updated = PlaybackStateStore.deletePlaylist(getApplication(), name)
        _uiState.value = _uiState.value.copy(playlists = updated)
    }

    fun addToPlaylist(name: String, songId: Long) {
        val updated = PlaybackStateStore.addToPlaylist(getApplication(), name, songId)
        _uiState.value = _uiState.value.copy(playlists = updated)
    }

    fun removeFromPlaylist(name: String, songId: Long) {
        val updated = PlaybackStateStore.removeFromPlaylist(getApplication(), name, songId)
        _uiState.value = _uiState.value.copy(playlists = updated)
    }

    override fun onCleared() {
        sleepTimerJob?.cancel()
        controller?.release()
        controller = null
        super.onCleared()
    }
}
