package com.hari.nothingplayer

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class PlayerUiState(
    val songs: List<Song> = emptyList(),
    val currentIndex: Int = -1,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val permissionGranted: Boolean = false
)

class PlayerViewModel(application: Application) : AndroidViewModel(application) {

    private val exoPlayer: ExoPlayer = ExoPlayer.Builder(application).build()

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState

    init {
        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _uiState.value = _uiState.value.copy(isPlaying = isPlaying)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val idx = _uiState.value.songs.indexOfFirst { it.uri.toString() == mediaItem?.mediaId }
                if (idx >= 0) _uiState.value = _uiState.value.copy(currentIndex = idx)
            }
        })

        // Poll playback position for the progress bar
        viewModelScope.launch {
            while (true) {
                _uiState.value = _uiState.value.copy(
                    positionMs = exoPlayer.currentPosition.coerceAtLeast(0),
                    durationMs = exoPlayer.duration.coerceAtLeast(0)
                )
                delay(500)
            }
        }
    }

    fun onPermissionGranted() {
        val songs = SongScanner.scanDevice(getApplication())
        _uiState.value = _uiState.value.copy(songs = songs, permissionGranted = true)

        exoPlayer.setMediaItems(
            songs.map { song ->
                MediaItem.Builder()
                    .setMediaId(song.uri.toString())
                    .setUri(song.uri)
                    .build()
            }
        )
        exoPlayer.prepare()
    }

    fun playAt(index: Int) {
        exoPlayer.seekTo(index, 0)
        exoPlayer.play()
        _uiState.value = _uiState.value.copy(currentIndex = index)
    }

    fun togglePlayPause() {
        if (_uiState.value.currentIndex == -1) {
            if (_uiState.value.songs.isNotEmpty()) playAt(0)
            return
        }
        if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
    }

    fun next() = exoPlayer.seekToNextMediaItem()
    fun previous() {
        if (exoPlayer.currentPosition > 3000) {
            exoPlayer.seekTo(0)
        } else {
            exoPlayer.seekToPreviousMediaItem()
        }
    }

    fun seekTo(ms: Long) = exoPlayer.seekTo(ms)

    override fun onCleared() {
        exoPlayer.release()
        super.onCleared()
    }
}
