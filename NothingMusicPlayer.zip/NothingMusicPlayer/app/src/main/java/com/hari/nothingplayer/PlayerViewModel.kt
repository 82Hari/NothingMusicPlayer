package com.hari.nothingplayer

import android.app.Application
import android.content.ComponentName
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// repeatMode: 0 = off, 1 = repeat all, 2 = repeat one
data class PlayerUiState(
    val songs: List<Song> = emptyList(),
    val currentIndex: Int = -1,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val permissionGranted: Boolean = false,
    val shuffleOn: Boolean = false,
    val repeatMode: Int = 0,
    val favorites: Set<Long> = emptySet(),
    val searchQuery: String = "",
    val favoritesOnly: Boolean = false
)

class PlayerViewModel(application: Application) : AndroidViewModel(application) {

    private var controller: MediaController? = null

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _uiState.value = _uiState.value.copy(isPlaying = isPlaying)
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val idx = _uiState.value.songs.indexOfFirst { it.uri.toString() == mediaItem?.mediaId }
            if (idx >= 0) _uiState.value = _uiState.value.copy(currentIndex = idx)
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            _uiState.value = _uiState.value.copy(shuffleOn = shuffleModeEnabled)
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            val mapped = when (repeatMode) {
                Player.REPEAT_MODE_ALL -> 1
                Player.REPEAT_MODE_ONE -> 2
                else -> 0
            }
            _uiState.value = _uiState.value.copy(repeatMode = mapped)
        }
    }

    init {
        val app: Application = application
        val sessionToken = SessionToken(app, ComponentName(app, MusicPlaybackService::class.java))
        val controllerFuture = MediaController.Builder(app, sessionToken).buildAsync()
        controllerFuture.addListener({
            controller = controllerFuture.get()
            controller?.addListener(playerListener)
        }, MoreExecutors.directExecutor())

        // Poll playback position for the progress bar
        viewModelScope.launch {
            while (true) {
                val c = controller
                if (c != null) {
                    _uiState.value = _uiState.value.copy(
                        positionMs = c.currentPosition.coerceAtLeast(0),
                        durationMs = c.duration.coerceAtLeast(0)
                    )
                }
                delay(500)
            }
        }

        // Load saved favorites
        val savedFavorites = FavoritesStore.load(application)
        _uiState.value = _uiState.value.copy(favorites = savedFavorites)
    }

    fun onPermissionGranted() {
        val songs = SongScanner.scanDevice(getApplication())
        _uiState.value = _uiState.value.copy(songs = songs, permissionGranted = true)

        val mediaItems = songs.map { song ->
            MediaItem.Builder()
                .setMediaId(song.uri.toString())
                .setUri(song.uri)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(song.title)
                        .setArtist(song.artist)
                        .setArtworkUri(song.artworkUri)
                        .build()
                )
                .build()
        }
        controller?.setMediaItems(mediaItems)
        controller?.prepare()
    }

    fun playAt(index: Int) {
        controller?.seekTo(index, 0)
        controller?.play()
        _uiState.value = _uiState.value.copy(currentIndex = index)
    }

    fun togglePlayPause() {
        val c = controller ?: return
        if (_uiState.value.currentIndex == -1) {
            if (_uiState.value.songs.isNotEmpty()) playAt(0)
            return
        }
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() {
        controller?.seekToNextMediaItem()
    }

    fun previous() {
        val c = controller ?: return
        if (c.currentPosition > 3000) {
            c.seekTo(0)
        } else {
            c.seekToPreviousMediaItem()
        }
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    fun cycleRepeatMode() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun toggleFavorite(songId: Long) {
        val current = _uiState.value.favorites
        val updated = if (current.contains(songId)) current - songId else current + songId
        _uiState.value = _uiState.value.copy(favorites = updated)
        FavoritesStore.save(getApplication(), updated)
    }

    fun setSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun toggleFavoritesOnly() {
        _uiState.value = _uiState.value.copy(favoritesOnly = !_uiState.value.favoritesOnly)
    }

    override fun onCleared() {
        controller?.release()
        controller = null
        super.onCleared()
    }
}
