package com.hari.nothingplayer

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.hari.nothingplayer.ui.NBlack
import com.hari.nothingplayer.ui.NRed
import com.hari.nothingplayer.ui.NText
import com.hari.nothingplayer.ui.NTextDim
import com.hari.nothingplayer.ui.PlayerScreen

class MainActivity : ComponentActivity() {

    private val viewModel: PlayerViewModel by viewModels()

    @OptIn(ExperimentalPermissionsApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                val audioPermission = if (Build.VERSION.SDK_INT >= 33)
                    Manifest.permission.READ_MEDIA_AUDIO
                else
                    Manifest.permission.READ_EXTERNAL_STORAGE

                val permissions = if (Build.VERSION.SDK_INT >= 33) {
                    listOf(audioPermission, Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    listOf(audioPermission)
                }

                val permissionsState = rememberMultiplePermissionsState(permissions)

                Surface(color = NBlack, modifier = Modifier.fillMaxSize()) {
                    val audioGranted = permissionsState.permissions.any {
                        it.permission == audioPermission && it.status.isGranted
                    }

                    if (audioGranted) {
                        // Scan device once permission is confirmed
                        androidx.compose.runtime.LaunchedEffect(Unit) {
                            viewModel.onPermissionGranted()
                        }
                        PlayerScreen(viewModel = viewModel)
                    } else {
                        PermissionRequestScreen(onGrant = { permissionsState.launchMultiplePermissionRequest() })
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionRequestScreen(onGrant: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NBlack)
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("● PLAYER", color = NRed, fontSize = 12.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(12.dp))
        Text(
            "ALLOW ACCESS TO YOUR MUSIC",
            color = NText,
            fontSize = 18.sp,
            textAlign = TextAlign.Center,
            letterSpacing = 1.sp
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Needed to find songs on your device and show playback controls",
            color = NTextDim,
            fontSize = 12.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onGrant) {
            Text("GRANT ACCESS")
        }
    }
}
