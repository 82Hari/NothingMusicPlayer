package com.hari.nothingplayer

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.hari.nothingplayer.ui.LocalAppColors
import com.hari.nothingplayer.ui.NBackgroundBrush
import com.hari.nothingplayer.ui.NRed
import com.hari.nothingplayer.ui.NText
import com.hari.nothingplayer.ui.NTextDim
import com.hari.nothingplayer.ui.PlayerScreen
import com.hari.nothingplayer.ui.colorsFor

class MainActivity : ComponentActivity() {

    private val viewModel: PlayerViewModel by viewModels()

    @OptIn(ExperimentalPermissionsApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                val context = LocalContext.current
                var currentTheme by remember { mutableStateOf(ThemeStore.load(context)) }

                CompositionLocalProvider(LocalAppColors provides colorsFor(currentTheme)) {
                    val audioPermission = if (Build.VERSION.SDK_INT >= 33)
                        Manifest.permission.READ_MEDIA_AUDIO
                    else
                        Manifest.permission.READ_EXTERNAL_STORAGE

                    val permissions = if (Build.VERSION.SDK_INT >= 33) {
                        listOf(audioPermission, Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.RECORD_AUDIO)
                    } else {
                        listOf(audioPermission, Manifest.permission.RECORD_AUDIO)
                    }

                    val permissionsState = rememberMultiplePermissionsState(permissions)

                    Surface(color = androidx.compose.ui.graphics.Color.Transparent, modifier = Modifier
                        .fillMaxSize()
                        .background(NBackgroundBrush)) {
                        val audioGranted = permissionsState.permissions.any {
                            it.permission == audioPermission && it.status.isGranted
                        }
                        // Only used for the waveform visualizer, never gates access to the app.
                        val recordAudioGranted = permissionsState.permissions.any {
                            it.permission == Manifest.permission.RECORD_AUDIO && it.status.isGranted
                        }

                        if (audioGranted) {
                            // Scan device once permission is confirmed
                            androidx.compose.runtime.LaunchedEffect(Unit) {
                                viewModel.onPermissionGranted()
                            }
                            androidx.compose.runtime.LaunchedEffect(recordAudioGranted) {
                                viewModel.onRecordAudioPermission(recordAudioGranted)
                            }
                            PlayerScreen(
                                viewModel = viewModel,
                                currentTheme = currentTheme,
                                onThemeSelected = { theme ->
                                    currentTheme = theme
                                    ThemeStore.save(context, theme)
                                }
                            )
                        } else {
                            PermissionRequestScreen(onGrant = { permissionsState.launchMultiplePermissionRequest() })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionRequestScreen(onGrant: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NBackgroundBrush)
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("● PLAYER", color = NRed, fontSize = 12.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(12.dp))
        Text(
            "ALLOW ACCESS TO YOUR MUSIC",
            color = NText,
            fontSize = 18.sp,
            textAlign = TextAlign.Center,
            letterSpacing = 1.sp
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Needed to find songs on your device and show playback controls",
            color = NTextDim,
            fontSize = 12.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onGrant) {
            Text("GRANT ACCESS")
        }
    }
}
