package com.hari.nothingplayer

import android.content.Context

/**
 * There's no real backend or account system in this app — it's a local
 * device player. The Welcome Back / Sign Up / Forget Password screens exist
 * purely to match a requested UI look, so "logging in" just means "leave
 * these fields blank check passed once" and this flag remembers that so the
 * flow only shows on first launch, not every time the app opens.
 */
object AuthGateStore {

    private const val PREFS = "auth_gate_prefs"
    private const val KEY_COMPLETED = "auth_completed"

    fun hasCompletedAuth(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_COMPLETED, false)

    fun setCompleted(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_COMPLETED, true).apply()
    }
}
