package com.hari.nothingplayer

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * The ExoPlayer instance driving playback lives inside [MusicPlaybackService],
 * but audio effects (Equalizer, BassBoost, Virtualizer, LoudnessEnhancer) and
 * the waveform Visualizer are attached by *audio session id*, not by holding
 * a reference to the player itself. This object is the single place that id
 * gets published to, so anything else in the app process (the view model,
 * the effects controller, the visualizer) can attach to the same session
 * without the service and the rest of the app needing direct references to
 * each other.
 *
 * A value of 0 (AudioManager.AUDIO_SESSION_ID_GENERATE / unset) means no
 * player has been created yet, or ExoPlayer hasn't allocated a session.
 */
object AudioSessionHolder {

    private val _sessionId = MutableStateFlow(0)
    val sessionId: StateFlow<Int> = _sessionId

    fun publish(sessionId: Int) {
        if (sessionId != 0 && sessionId != _sessionId.value) {
            _sessionId.value = sessionId
        }
    }

    fun clear() {
        _sessionId.value = 0
    }
}
