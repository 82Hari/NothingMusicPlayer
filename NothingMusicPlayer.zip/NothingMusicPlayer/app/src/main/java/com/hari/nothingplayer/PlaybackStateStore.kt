package com.hari.nothingplayer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Persists playback resume position, recently played history, and playlists
 * across app restarts using SharedPreferences.
 */
object PlaybackStateStore {
    private const val PREFS = "nothing_player_playback_state"
    private const val KEY_LAST_SONG_ID = "last_song_id"
    private const val KEY_LAST_POSITION = "last_position_ms"
    private const val KEY_RECENT = "recently_played"
    private const val KEY_PLAYLISTS = "playlists_json"
    private const val MAX_RECENT = 20

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun saveLastPlayed(context: Context, songId: Long, positionMs: Long) {
        prefs(context).edit()
            .putLong(KEY_LAST_SONG_ID, songId)
            .putLong(KEY_LAST_POSITION, positionMs)
            .apply()
    }

    fun loadLastPlayed(context: Context): Pair<Long, Long>? {
        val p = prefs(context)
        val id = p.getLong(KEY_LAST_SONG_ID, -1L)
        if (id == -1L) return null
        val pos = p.getLong(KEY_LAST_POSITION, 0L)
        return id to pos
    }

    fun addRecentlyPlayed(context: Context, songId: Long) {
        val current = getRecentlyPlayed(context).toMutableList()
        current.remove(songId)
        current.add(0, songId)
        val trimmed = current.take(MAX_RECENT)
        prefs(context).edit().putString(KEY_RECENT, trimmed.joinToString(",")).apply()
    }

    fun getRecentlyPlayed(context: Context): List<Long> {
        val raw = prefs(context).getString(KEY_RECENT, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return raw.split(",").mapNotNull { it.toLongOrNull() }
    }

    fun getPlaylists(context: Context): Map<String, List<Long>> {
        val raw = prefs(context).getString(KEY_PLAYLISTS, null) ?: return emptyMap()
        return try {
            val obj = JSONObject(raw)
            val result = mutableMapOf<String, List<Long>>()
            val keysIterator = obj.keys()
            while (keysIterator.hasNext()) {
                val name = keysIterator.next()
                val arr = obj.getJSONArray(name)
                val ids = mutableListOf<Long>()
                for (i in 0 until arr.length()) ids.add(arr.getLong(i))
                result[name] = ids
            }
            result
        } catch (e: Exception) {
            emptyMap()
        }
    }

    private fun savePlaylists(context: Context, playlists: Map<String, List<Long>>) {
        val obj = JSONObject()
        playlists.forEach { (name, ids) ->
            obj.put(name, JSONArray(ids))
        }
        prefs(context).edit().putString(KEY_PLAYLISTS, obj.toString()).apply()
    }

    fun createPlaylist(context: Context, name: String): Map<String, List<Long>> {
        val playlists = getPlaylists(context).toMutableMap()
        if (!playlists.containsKey(name)) {
            playlists[name] = emptyList()
            savePlaylists(context, playlists)
        }
        return playlists
    }

    fun deletePlaylist(context: Context, name: String): Map<String, List<Long>> {
        val playlists = getPlaylists(context).toMutableMap()
        playlists.remove(name)
        savePlaylists(context, playlists)
        return playlists
    }

    fun addToPlaylist(context: Context, name: String, songId: Long): Map<String, List<Long>> {
        val playlists = getPlaylists(context).toMutableMap()
        val current = playlists[name]?.toMutableList() ?: mutableListOf()
        if (!current.contains(songId)) {
            current.add(songId)
            playlists[name] = current
            savePlaylists(context, playlists)
        }
        return playlists
    }

    fun removeFromPlaylist(context: Context, name: String, songId: Long): Map<String, List<Long>> {
        val playlists = getPlaylists(context).toMutableMap()
        val current = playlists[name]?.toMutableList() ?: return playlists
        current.remove(songId)
        playlists[name] = current
        savePlaylists(context, playlists)
        return playlists
    }
}
