package com.hari.nothingplayer.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hari.nothingplayer.PlayerUiState
import com.hari.nothingplayer.PlayerViewModel
import com.hari.nothingplayer.Song
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.roundToInt

@Composable
fun PlayerScreen(viewModel: PlayerViewModel) {
    val state by viewModel.uiState.collectAsState()
    var showQueue by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NBlack)
            .padding(horizontal = 24.dp, vertical = 20.dp)
    ) {
        if (!showQueue) {
            NowPlayingView(
                state = state,
                onTogglePlay = { viewModel.togglePlayPause() },
                onNext = { viewModel.next() },
                onPrevious = { viewModel.previous() },
                onSeek = { viewModel.seekTo(it) },
                onOpenQueue = { showQueue = true },
                onToggleShuffle = { viewModel.toggleShuffle() },
                onCycleRepeat = { viewModel.cycleRepeatMode() },
                onToggleFavorite = { id -> viewModel.toggleFavorite(id) }
            )
        } else {
            QueueView(
                state = state,
                onSelect = { viewModel.playAt(it); showQueue = false },
                onClose = { showQueue = false },
                onSearchChange = { viewModel.setSearchQuery(it) },
                onToggleFavoritesOnly = { viewModel.toggleFavoritesOnly() },
                onToggleFavorite = { id -> viewModel.toggleFavorite(id) }
            )
        }
    }
}

@Composable
private fun NowPlayingView(
    state: PlayerUiState,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onOpenQueue: () -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onToggleFavorite: (Long) -> Unit
) {
    val current = state.songs.getOrNull(state.currentIndex)

    Column(modifier = Modifier.fillMaxSize()) {

        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("● PLAYER", color = NRed, fontSize = 10.sp, letterSpacing = 3.sp)
                Text(
                    "LIBRARY",
                    color = NText,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 2.sp
                )
            }
            IconButton(
                onClick = onOpenQueue,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .border(1.dp, NHairline, CircleShape)
            ) {
                Icon(Icons.Default.QueueMusic, contentDescription = "Queue", tint = NText)
            }
        }
        Divider(color = NHairlineDim, thickness = 1.dp)

        Spacer(Modifier.weight(1f))

        // Dot ring visualizer
        Box(contentAlignment = Alignment.Center, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            DotRingVisualizer(isPlaying = state.isPlaying, hasTrack = current != null)
        }

        Spacer(Modifier.height(24.dp))

        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = current?.title?.uppercase() ?: "NO SIGNAL",
                    color = NText,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                if (current != null) {
                    Spacer(Modifier.width(8.dp))
                    val isFav = state.favorites.contains(current.id)
                    Icon(
                        imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (isFav) NRed else NTextDim,
                        modifier = Modifier
                            .size(20.dp)
                            .clickable { onToggleFavorite(current.id) }
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = current?.artist?.uppercase() ?: "GRANT PERMISSION TO SCAN DEVICE",
                color = NTextDim,
                fontSize = 10.sp,
                letterSpacing = 3.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(Modifier.weight(1f))

        // Dot-matrix progress bar
        DotProgressBar(
            positionMs = state.positionMs,
            durationMs = state.durationMs,
            onSeek = onSeek
        )

        Spacer(Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(formatMs(state.positionMs), color = NTextDim, fontSize = 9.sp, letterSpacing = 1.sp)
            Text(formatMs(state.durationMs), color = NTextDim, fontSize = 9.sp, letterSpacing = 1.sp)
        }

        Spacer(Modifier.height(20.dp))

        // Main controls with shuffle + repeat
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Shuffle,
                contentDescription = "Shuffle",
                tint = if (state.shuffleOn) NRed else NTextDim,
                modifier = Modifier
                    .size(20.dp)
                    .clickable { onToggleShuffle() }
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(28.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onPrevious, enabled = state.songs.isNotEmpty()) {
                    Icon(Icons.Default.SkipPrevious, contentDescription = "Previous", tint = NText, modifier = Modifier.size(28.dp))
                }
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(NRed)
                        .clickable { onTogglePlay() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Play/Pause",
                        tint = NBlack,
                        modifier = Modifier.size(30.dp)
                    )
                }
                IconButton(onClick = onNext, enabled = state.songs.isNotEmpty()) {
                    Icon(Icons.Default.SkipNext, contentDescription = "Next", tint = NText, modifier = Modifier.size(28.dp))
                }
            }

            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clickable { onCycleRepeat() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (state.repeatMode == 2) Icons.Default.RepeatOne else Icons.Default.Repeat,
                    contentDescription = "Repeat",
                    tint = if (state.repeatMode != 0) NRed else NTextDim,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun DotRingVisualizer(isPlaying: Boolean, hasTrack: Boolean) {
    val infinite = rememberInfiniteTransition(label = "ring")
    val pulse by infinite.animateFloat(
        initialValue = 1f,
        targetValue = if (isPlaying) 1.08f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    val rotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isPlaying) 6000 else 60000, easing = LinearEasing)
        ),
        label = "rot"
    )

    Box(
        modifier = Modifier
            .size(200.dp)
            .border(1.dp, NHairline, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        val dotCount = 24
        Box(modifier = Modifier.size(200.dp)) {
            for (i in 0 until dotCount) {
                val angle = (i.toFloat() / dotCount) * 2 * Math.PI + Math.toRadians(rotation.toDouble())
                val radius = 92
                val x = (100 + radius * cos(angle)).roundToInt()
                val y = (100 + radius * sin(angle)).roundToInt()
                val active = isPlaying && (i % 5 == (rotation.toInt() / 15) % 5)
                Box(
                    modifier = Modifier
                        .offset(x = x.dp, y = y.dp)
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(if (active) NRed else NHairline)
                )
            }
        }

        Box(
            modifier = Modifier
                .size((90 * pulse).dp)
                .clip(CircleShape)
                .border(2.dp, if (hasTrack) NRed else NHairline, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(if (hasTrack) NRed else NTextDim)
            )
        }
    }
}

@Composable
private fun DotProgressBar(positionMs: Long, durationMs: Long, onSeek: (Long) -> Unit) {
    val dots = 40
    val progress = if (durationMs > 0) positionMs.toFloat() / durationMs else 0f
    val filled = (progress * dots).roundToInt().coerceIn(0, dots)
    var widthPx by remember { mutableStateOf(0) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(16.dp)
            .pointerInput(durationMs) {
                detectTapGestures { offset ->
                    if (widthPx > 0 && durationMs > 0) {
                        val ratio = (offset.x / widthPx).coerceIn(0f, 1f)
                        onSeek((ratio * durationMs).toLong())
                    }
                }
            }
            .onSizeChanged { widthPx = it.width },
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until dots) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (i < filled) NRed else NHairlineDim)
            )
        }
    }
}

@Composable
private fun QueueView(
    state: PlayerUiState,
    onSelect: (Int) -> Unit,
    onClose: () -> Unit,
    onSearchChange: (String) -> Unit,
    onToggleFavoritesOnly: () -> Unit,
    onToggleFavorite: (Long) -> Unit
) {
    val filteredSongs = remember(state.songs, state.searchQuery, state.favoritesOnly, state.favorites) {
        state.songs.filter { song ->
            val matchesQuery = state.searchQuery.isBlank() ||
                song.title.contains(state.searchQuery, ignoreCase = true) ||
                song.artist.contains(state.searchQuery, ignoreCase = true)
            val matchesFavorite = !state.favoritesOnly || state.favorites.contains(song.id)
            matchesQuery && matchesFavorite
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "TRACKS (${filteredSongs.size})",
                color = NText,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 2.sp
            )
            IconButton(
                onClick = onClose,
                modifier = Modifier.size(36.dp).clip(CircleShape).border(1.dp, NHairline, CircleShape)
            ) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = NText)
            }
        }
        Divider(color = NHairlineDim, thickness = 1.dp)
        Spacer(Modifier.height(12.dp))

        // Search bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(999.dp))
                .border(1.dp, NHairline, RoundedCornerShape(999.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Search, contentDescription = null, tint = NTextDim, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Box(modifier = Modifier.weight(1f)) {
                if (state.searchQuery.isEmpty()) {
                    Text("Search tracks or artists", color = NTextDim, fontSize = 12.sp)
                }
                BasicTextField(
                    value = state.searchQuery,
                    onValueChange = onSearchChange,
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(color = NText, fontSize = 12.sp),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(NRed),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        // Favorites-only filter chip
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(999.dp))
                .border(
                    1.dp,
                    if (state.favoritesOnly) NRed else NHairline,
                    RoundedCornerShape(999.dp)
                )
                .clickable { onToggleFavoritesOnly() }
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (state.favoritesOnly) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = null,
                tint = if (state.favoritesOnly) NRed else NTextDim,
                modifier = Modifier.size(13.dp)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                "FAVORITES",
                color = if (state.favoritesOnly) NRed else NTextDim,
                fontSize = 10.sp,
                letterSpacing = 1.sp
            )
        }

        Spacer(Modifier.height(12.dp))

        if (filteredSongs.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("NO TRACKS FOUND", color = NTextDim, fontSize = 11.sp, letterSpacing = 2.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(filteredSongs.size) { i ->
                    val song = filteredSongs[i]
                    val actualIndex = state.songs.indexOf(song)
                    val isCurrent = actualIndex == state.currentIndex
                    SongRow(
                        song = song,
                        isCurrent = isCurrent,
                        isPlaying = state.isPlaying,
                        isFavorite = state.favorites.contains(song.id),
                        onClick = { onSelect(actualIndex) },
                        onToggleFavorite = { onToggleFavorite(song.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SongRow(
    song: Song,
    isCurrent: Boolean,
    isPlaying: Boolean,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (isCurrent) NSurface else Color.Transparent)
            .border(
                1.dp,
                if (isCurrent) NRed.copy(alpha = 0.5f) else Color.Transparent,
                RoundedCornerShape(14.dp)
            )
            .clickable { onClick() }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .border(1.dp, if (isCurrent) NRed else NHairline, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isCurrent && isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = null,
                tint = if (isCurrent) NRed else NTextDim,
                modifier = Modifier.size(16.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                song.title,
                color = if (isCurrent) NRed else NText,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                song.artist.uppercase(),
                color = NTextDim,
                fontSize = 9.sp,
                letterSpacing = 1.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        Icon(
            imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
            contentDescription = "Favorite",
            tint = if (isFavorite) NRed else NTextDim,
            modifier = Modifier
                .size(18.dp)
                .clickable { onToggleFavorite() }
        )
    }
}

private fun formatMs(ms: Long): String {
    val totalSec = ms / 1000
    val m = totalSec / 60
    val s = totalSec % 60
    return "%d:%02d".format(m, s)
}
