package com.hari.nothingplayer.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import android.graphics.Bitmap
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import com.hari.nothingplayer.PlayerUiState
import com.hari.nothingplayer.PlayerViewModel
import com.hari.nothingplayer.Song
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.roundToInt

private const val SCREEN_NOW = "now"
private const val SCREEN_QUEUE = "queue"
private const val SCREEN_PLAYLISTS = "playlists"

@Composable
fun PlayerScreen(viewModel: PlayerViewModel) {
    val state by viewModel.uiState.collectAsState()
    var screen by remember { mutableStateOf(SCREEN_NOW) }
    var selectedPlaylist by remember { mutableStateOf<String?>(null) }
    var showSleepDialog by remember { mutableStateOf(false) }
    var addToPlaylistSongId by remember { mutableStateOf<Long?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NBlack)
            .padding(horizontal = 24.dp, vertical = 20.dp)
    ) {
        when (screen) {
            SCREEN_NOW -> NowPlayingView(
                state = state,
                onTogglePlay = { viewModel.togglePlayPause() },
                onNext = { viewModel.next() },
                onPrevious = { viewModel.previous() },
                onSeek = { viewModel.seekTo(it) },
                onOpenQueue = { screen = SCREEN_QUEUE },
                onOpenPlaylists = { screen = SCREEN_PLAYLISTS; selectedPlaylist = null },
                onOpenSleepTimer = { showSleepDialog = true },
                onToggleShuffle = { viewModel.toggleShuffle() },
                onCycleRepeat = { viewModel.cycleRepeatMode() },
                onToggleFavorite = { id -> viewModel.toggleFavorite(id) },
                onSetVolume = { viewModel.setVolume(it) }
            )
            SCREEN_QUEUE -> QueueView(
                state = state,
                onSelect = { viewModel.playAt(it); screen = SCREEN_NOW },
                onClose = { screen = SCREEN_NOW },
                onSearchChange = { viewModel.setSearchQuery(it) },
                onToggleFavoritesOnly = { viewModel.toggleFavoritesOnly() },
                onToggleRecentOnly = { viewModel.toggleRecentOnly() },
                onToggleFavorite = { id -> viewModel.toggleFavorite(id) },
                onAddToPlaylist = { id -> addToPlaylistSongId = id }
            )
            SCREEN_PLAYLISTS -> {
                if (selectedPlaylist == null) {
                    PlaylistsListView(
                        state = state,
                        onClose = { screen = SCREEN_NOW },
                        onOpenPlaylist = { selectedPlaylist = it },
                        onCreatePlaylist = { name -> viewModel.createPlaylist(name) },
                        onDeletePlaylist = { name -> viewModel.deletePlaylist(name) }
                    )
                } else {
                    PlaylistDetailView(
                        state = state,
                        playlistName = selectedPlaylist!!,
                        onBack = { selectedPlaylist = null },
                        onSelect = { idx -> viewModel.playAt(idx); screen = SCREEN_NOW },
                        onRemove = { songId -> viewModel.removeFromPlaylist(selectedPlaylist!!, songId) }
                    )
                }
            }
        }

        if (showSleepDialog) {
            SleepTimerDialog(
                activeEndAt = state.sleepTimerEndAt,
                onDismiss = { showSleepDialog = false },
                onSelect = { minutes -> viewModel.startSleepTimer(minutes); showSleepDialog = false },
                onCancelTimer = { viewModel.cancelSleepTimer(); showSleepDialog = false }
            )
        }

        addToPlaylistSongId?.let { songId ->
            AddToPlaylistDialog(
                playlists = state.playlists,
                songId = songId,
                onDismiss = { addToPlaylistSongId = null },
                onToggle = { name, checked ->
                    if (checked) viewModel.addToPlaylist(name, songId)
                    else viewModel.removeFromPlaylist(name, songId)
                },
                onCreate = { name -> viewModel.createPlaylist(name) }
            )
        }
    }
}

@Composable
private fun NowPlayingView(
    state: PlayerUiState,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onOpenQueue: () -> Unit,
    onOpenPlaylists: () -> Unit,
    onOpenSleepTimer: () -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onToggleFavorite: (Long) -> Unit,
    onSetVolume: (Int) -> Unit
) {
    val current = state.songs.getOrNull(state.currentIndex)

    Column(modifier = Modifier.fillMaxSize()) {

        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("● PLAYER", color = NRed, fontSize = 10.sp, letterSpacing = 3.sp)
                Text(
                    "LIBRARY",
                    color = NText,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 2.sp
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HeaderIconButton(
                    icon = Icons.Default.Bedtime,
                    tint = if (state.sleepTimerEndAt != null) NRed else NText,
                    onClick = onOpenSleepTimer
                )
                HeaderIconButton(icon = Icons.Default.LibraryMusic, tint = NText, onClick = onOpenPlaylists)
                HeaderIconButton(icon = Icons.Default.QueueMusic, tint = NText, onClick = onOpenQueue)
            }
        }
        Divider(color = NHairlineDim, thickness = 1.dp)

        Spacer(Modifier.weight(1f))

        Box(contentAlignment = Alignment.Center, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            DotRingVisualizer(isPlaying = state.isPlaying, hasTrack = current != null, artwork = state.currentArtwork)
        }

        Spacer(Modifier.height(24.dp))

        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = current?.title?.uppercase() ?: "NO SIGNAL",
                    color = NText,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                if (current != null) {
                    Spacer(Modifier.width(8.dp))
                    val isFav = state.favorites.contains(current.id)
                    Icon(
                        imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (isFav) NRed else NTextDim,
                        modifier = Modifier
                            .size(20.dp)
                            .clickable { onToggleFavorite(current.id) }
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = current?.artist?.uppercase() ?: "GRANT PERMISSION TO SCAN DEVICE",
                color = NTextDim,
                fontSize = 10.sp,
                letterSpacing = 3.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(Modifier.weight(1f))

        DotProgressBar(
            positionMs = state.positionMs,
            durationMs = state.durationMs,
            onSeek = onSeek
        )

        Spacer(Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(formatMs(state.positionMs), color = NTextDim, fontSize = 9.sp, letterSpacing = 1.sp)
            Text(formatMs(state.durationMs), color = NTextDim, fontSize = 9.sp, letterSpacing = 1.sp)
        }

        Spacer(Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Shuffle,
                contentDescription = "Shuffle",
                tint = if (state.shuffleOn) NRed else NTextDim,
                modifier = Modifier
                    .size(20.dp)
                    .clickable { onToggleShuffle() }
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(28.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onPrevious, enabled = state.songs.isNotEmpty()) {
                    Icon(Icons.Default.SkipPrevious, contentDescription = "Previous", tint = NText, modifier = Modifier.size(28.dp))
                }
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(NRed)
                        .clickable { onTogglePlay() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Play/Pause",
                        tint = NBlack,
                        modifier = Modifier.size(30.dp)
                    )
                }
                IconButton(onClick = onNext, enabled = state.songs.isNotEmpty()) {
                    Icon(Icons.Default.SkipNext, contentDescription = "Next", tint = NText, modifier = Modifier.size(28.dp))
                }
            }

            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clickable { onCycleRepeat() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (state.repeatMode == 2) Icons.Default.RepeatOne else Icons.Default.Repeat,
                    contentDescription = "Repeat",
                    tint = if (state.repeatMode != 0) NRed else NTextDim,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        VolumeOutputRow(
            volumePercent = state.volumePercent,
            outputLabel = state.outputLabel,
            outputIsBluetooth = state.outputIsBluetooth,
            onSetVolume = onSetVolume
        )

        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun VolumeOutputRow(
    volumePercent: Int,
    outputLabel: String,
    outputIsBluetooth: Boolean,
    onSetVolume: (Int) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (outputIsBluetooth) Icons.Default.Bluetooth else Icons.Default.VolumeUp,
                contentDescription = "Output",
                tint = if (outputIsBluetooth) NRed else NTextDim,
                modifier = Modifier.size(16.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = outputLabel.uppercase(),
                color = NTextDim,
                fontSize = 9.sp,
                letterSpacing = 2.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "$volumePercent%",
                color = NTextDim,
                fontSize = 9.sp,
                letterSpacing = 1.sp
            )
        }
        Spacer(Modifier.height(4.dp))
        Slider(
            value = volumePercent.toFloat(),
            onValueChange = { onSetVolume(it.roundToInt()) },
            valueRange = 0f..100f,
            colors = SliderDefaults.colors(
                thumbColor = NRed,
                activeTrackColor = NRed,
                inactiveTrackColor = NHairlineDim
            ),
            modifier = Modifier.fillMaxWidth().height(20.dp)
        )
    }
}

@Composable
private fun HeaderIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, onClick: () -> Unit) {
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .border(1.dp, NHairline, CircleShape)
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun DotRingVisualizer(isPlaying: Boolean, hasTrack: Boolean, artwork: Bitmap? = null) {
    val infinite = rememberInfiniteTransition(label = "ring")
    val pulse by infinite.animateFloat(
        initialValue = 1f,
        targetValue = if (isPlaying) 1.08f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    val rotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isPlaying) 6000 else 60000, easing = LinearEasing)
        ),
        label = "rot"
    )

    Box(
        modifier = Modifier
            .size(200.dp)
            .border(1.dp, NHairline, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        val dotCount = 24
        Box(modifier = Modifier.size(200.dp)) {
            for (i in 0 until dotCount) {
                val angle = (i.toFloat() / dotCount) * 2 * Math.PI + Math.toRadians(rotation.toDouble())
                val radius = 92
                val x = (100 + radius * cos(angle)).roundToInt()
                val y = (100 + radius * sin(angle)).roundToInt()
                val active = isPlaying && (i % 5 == (rotation.toInt() / 15) % 5)
                Box(
                    modifier = Modifier
                        .offset(x = x.dp, y = y.dp)
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(if (active) NRed else NHairline)
                )
            }
        }

        Box(
            modifier = Modifier
                .size((90 * pulse).dp)
                .clip(CircleShape)
                .background(NSurface)
                .border(2.dp, if (hasTrack) NRed else NHairline, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (artwork != null) {
                Image(
                    bitmap = artwork.asImageBitmap(),
                    contentDescription = "Album art",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size((84 * pulse).dp)
                        .clip(CircleShape)
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (hasTrack) NRed else NTextDim)
                )
            }
        }
    }
}

@Composable
private fun DotProgressBar(positionMs: Long, durationMs: Long, onSeek: (Long) -> Unit) {
    val dots = 40
    val progress = if (durationMs > 0) positionMs.toFloat() / durationMs else 0f
    val filled = (progress * dots).roundToInt().coerceIn(0, dots)
    var widthPx by remember { mutableStateOf(0) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(16.dp)
            .pointerInput(durationMs) {
                detectTapGestures { offset ->
                    if (widthPx > 0 && durationMs > 0) {
                        val ratio = (offset.x / widthPx).coerceIn(0f, 1f)
                        onSeek((ratio * durationMs).toLong())
                    }
                }
            }
            .onSizeChanged { widthPx = it.width },
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until dots) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (i < filled) NRed else NHairlineDim)
            )
        }
    }
}

@Composable
private fun QueueView(
    state: PlayerUiState,
    onSelect: (Int) -> Unit,
    onClose: () -> Unit,
    onSearchChange: (String) -> Unit,
    onToggleFavoritesOnly: () -> Unit,
    onToggleRecentOnly: () -> Unit,
    onToggleFavorite: (Long) -> Unit,
    onAddToPlaylist: (Long) -> Unit
) {
    val filteredSongs = remember(state.songs, state.searchQuery, state.favoritesOnly, state.recentOnly, state.favorites, state.recentlyPlayed) {
        val base = if (state.recentOnly) {
            state.recentlyPlayed.mapNotNull { id -> state.songs.find { it.id == id } }
        } else {
            state.songs
        }
        base.filter { song ->
            val matchesQuery = state.searchQuery.isBlank() ||
                song.title.contains(state.searchQuery, ignoreCase = true) ||
                song.artist.contains(state.searchQuery, ignoreCase = true)
            val matchesFavorite = !state.favoritesOnly || state.favorites.contains(song.id)
            matchesQuery && matchesFavorite
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "TRACKS (${filteredSongs.size})",
                color = NText,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 2.sp
            )
            IconButton(
                onClick = onClose,
                modifier = Modifier.size(36.dp).clip(CircleShape).border(1.dp, NHairline, CircleShape)
            ) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = NText)
            }
        }
        Divider(color = NHairlineDim, thickness = 1.dp)
        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(999.dp))
                .border(1.dp, NHairline, RoundedCornerShape(999.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Search, contentDescription = null, tint = NTextDim, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Box(modifier = Modifier.weight(1f)) {
                if (state.searchQuery.isEmpty()) {
                    Text("Search tracks or artists", color = NTextDim, fontSize = 12.sp)
                }
                BasicTextField(
                    value = state.searchQuery,
                    onValueChange = onSearchChange,
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(color = NText, fontSize = 12.sp),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(NRed),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PlayerFilterChip(
                label = "FAVORITES",
                icon = if (state.favoritesOnly) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                active = state.favoritesOnly,
                onClick = onToggleFavoritesOnly
            )
            PlayerFilterChip(
                label = "RECENT",
                icon = Icons.Default.History,
                active = state.recentOnly,
                onClick = onToggleRecentOnly
            )
        }

        Spacer(Modifier.height(12.dp))

        if (filteredSongs.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("NO TRACKS FOUND", color = NTextDim, fontSize = 11.sp, letterSpacing = 2.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(filteredSongs.size) { i ->
                    val song = filteredSongs[i]
                    val actualIndex = state.songs.indexOf(song)
                    val isCurrent = actualIndex == state.currentIndex
                    SongRow(
                        song = song,
                        isCurrent = isCurrent,
                        isPlaying = state.isPlaying,
                        isFavorite = state.favorites.contains(song.id),
                        onClick = { onSelect(actualIndex) },
                        onToggleFavorite = { onToggleFavorite(song.id) },
                        trailingIcon = Icons.Default.PlaylistAdd,
                        onTrailingClick = { onAddToPlaylist(song.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun PlayerFilterChip(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, active: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .border(1.dp, if (active) NRed else NHairline, RoundedCornerShape(999.dp))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = if (active) NRed else NTextDim, modifier = Modifier.size(13.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = if (active) NRed else NTextDim, fontSize = 10.sp, letterSpacing = 1.sp)
    }
}

@Composable
private fun PlaylistsListView(
    state: PlayerUiState,
    onClose: () -> Unit,
    onOpenPlaylist: (String) -> Unit,
    onCreatePlaylist: (String) -> Unit,
    onDeletePlaylist: (String) -> Unit
) {
    var showCreateDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "PLAYLISTS",
                color = NText,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 2.sp
            )
            IconButton(
                onClick = onClose,
                modifier = Modifier.size(36.dp).clip(CircleShape).border(1.dp, NHairline, CircleShape)
            ) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = NText)
            }
        }
        Divider(color = NHairlineDim, thickness = 1.dp)
        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, NHairline, RoundedCornerShape(14.dp))
                .clickable { showCreateDialog = true }
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Add, contentDescription = null, tint = NRed, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Text("NEW PLAYLIST", color = NRed, fontSize = 12.sp, letterSpacing = 1.sp)
        }

        Spacer(Modifier.height(12.dp))

        if (state.playlists.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("NO PLAYLISTS YET", color = NTextDim, fontSize = 11.sp, letterSpacing = 2.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(state.playlists.keys.toList()) { name ->
                    val count = state.playlists[name]?.size ?: 0
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(NSurface)
                            .clickable { onOpenPlaylist(name) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.LibraryMusic, contentDescription = null, tint = NTextDim, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(name, color = NText, fontSize = 13.sp)
                            Text("$count tracks", color = NTextDim, fontSize = 10.sp)
                        }
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Delete playlist",
                            tint = NTextDim,
                            modifier = Modifier
                                .size(16.dp)
                                .clickable { onDeletePlaylist(name) }
                        )
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreatePlaylistDialog(
            onDismiss = { showCreateDialog = false },
            onCreate = { name -> onCreatePlaylist(name); showCreateDialog = false }
        )
    }
}

@Composable
private fun PlaylistDetailView(
    state: PlayerUiState,
    playlistName: String,
    onBack: () -> Unit,
    onSelect: (Int) -> Unit,
    onRemove: (Long) -> Unit
) {
    val songIds = state.playlists[playlistName] ?: emptyList()
    val songs = songIds.mapNotNull { id -> state.songs.find { it.id == id } }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                playlistName.uppercase(),
                color = NText,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false)
            )
            IconButton(
                onClick = onBack,
                modifier = Modifier.size(36.dp).clip(CircleShape).border(1.dp, NHairline, CircleShape)
            ) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = NText)
            }
        }
        Divider(color = NHairlineDim, thickness = 1.dp)
        Spacer(Modifier.height(12.dp))

        if (songs.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("NO TRACKS IN THIS PLAYLIST", color = NTextDim, fontSize = 11.sp, letterSpacing = 2.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(songs.size) { i ->
                    val song = songs[i]
                    val actualIndex = state.songs.indexOf(song)
                    SongRow(
                        song = song,
                        isCurrent = actualIndex == state.currentIndex,
                        isPlaying = state.isPlaying,
                        isFavorite = state.favorites.contains(song.id),
                        onClick = { onSelect(actualIndex) },
                        onToggleFavorite = {},
                        trailingIcon = Icons.Default.Close,
                        onTrailingClick = { onRemove(song.id) },
                        showFavorite = false
                    )
                }
            }
        }
    }
}

@Composable
private fun SongRow(
    song: Song,
    isCurrent: Boolean,
    isPlaying: Boolean,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    trailingIcon: androidx.compose.ui.graphics.vector.ImageVector,
    onTrailingClick: () -> Unit,
    showFavorite: Boolean = true
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (isCurrent) NSurface else Color.Transparent)
            .border(
                1.dp,
                if (isCurrent) NRed.copy(alpha = 0.5f) else Color.Transparent,
                RoundedCornerShape(14.dp)
            )
            .clickable { onClick() }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .border(1.dp, if (isCurrent) NRed else NHairline, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isCurrent && isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = null,
                tint = if (isCurrent) NRed else NTextDim,
                modifier = Modifier.size(16.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                song.title,
                color = if (isCurrent) NRed else NText,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                song.artist.uppercase(),
                color = NTextDim,
                fontSize = 9.sp,
                letterSpacing = 1.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        if (showFavorite) {
            Icon(
                imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = "Favorite",
                tint = if (isFavorite) NRed else NTextDim,
                modifier = Modifier
                    .size(18.dp)
                    .clickable { onToggleFavorite() }
            )
            Spacer(Modifier.width(10.dp))
        }
        Icon(
            imageVector = trailingIcon,
            contentDescription = null,
            tint = NTextDim,
            modifier = Modifier
                .size(18.dp)
                .clickable { onTrailingClick() }
        )
    }
}

@Composable
private fun SleepTimerDialog(
    activeEndAt: Long?,
    onDismiss: () -> Unit,
    onSelect: (Int) -> Unit,
    onCancelTimer: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sleep timer") },
        text = {
            Column {
                if (activeEndAt != null) {
                    val remainingMin = ((activeEndAt - System.currentTimeMillis()) / 60000L).coerceAtLeast(0)
                    Text("Timer active — about $remainingMin min left")
                    Spacer(Modifier.height(8.dp))
                }
                listOf(15, 30, 45, 60).forEach { minutes ->
                    TextButton(onClick = { onSelect(minutes) }) {
                        Text("$minutes minutes")
                    }
                }
            }
        },
        confirmButton = {
            if (activeEndAt != null) {
                TextButton(onClick = onCancelTimer) { Text("Cancel timer") }
            } else {
                TextButton(onClick = onDismiss) { Text("Close") }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

@Composable
private fun CreatePlaylistDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New playlist") },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                singleLine = true,
                placeholder = { Text("Playlist name") }
            )
        },
        confirmButton = {
            TextButton(onClick = { if (name.isNotBlank()) onCreate(name) }) { Text("Create") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun AddToPlaylistDialog(
    playlists: Map<String, List<Long>>,
    songId: Long,
    onDismiss: () -> Unit,
    onToggle: (String, Boolean) -> Unit,
    onCreate: (String) -> Unit
) {
    var newName by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add to playlist") },
        text = {
            Column {
                if (playlists.isEmpty()) {
                    Text("No playlists yet — create one below.")
                }
                playlists.keys.toList().forEach { name ->
                    val checked = playlists[name]?.contains(songId) == true
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().clickable { onToggle(name, !checked) }
                    ) {
                        Checkbox(checked = checked, onCheckedChange = { onToggle(name, it) })
                        Text(name)
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    singleLine = true,
                    placeholder = { Text("New playlist name") }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (newName.isNotBlank()) {
                    onCreate(newName)
                    onToggle(newName, true)
                    newName = ""
                }
            }) { Text("Create & add") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Done") }
        }
    )
}

private fun formatMs(ms: Long): String {
    val totalSec = ms / 1000
    val m = totalSec / 60
    val s = totalSec % 60
    return "%d:%02d".format(m, s)
}
