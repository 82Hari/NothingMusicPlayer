package com.hari.nothingplayer

import android.media.audiofx.Visualizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Wraps android.media.audiofx.Visualizer to turn the raw waveform of
 * whatever's actually playing on [sessionId] into a small set of normalized
 * amplitude "buckets" (0f..1f) that the UI can bind directly to — e.g. one
 * value per dot in the ring visualizer.
 *
 * Requires RECORD_AUDIO permission (yes, even though it's only reading this
 * app's own playback, not the microphone — that's an Android platform
 * requirement for the Visualizer effect). If permission isn't granted, or
 * the device doesn't support it, [start] simply reports no levels and the
 * caller should fall back to a non-reactive animation.
 */
class VisualizerController(private val bucketCount: Int = 24) {

    private var visualizer: Visualizer? = null

    private val _levels = MutableStateFlow(FloatArray(bucketCount))
    val levels: StateFlow<FloatArray> = _levels

    private val _active = MutableStateFlow(false)
    val active: StateFlow<Boolean> = _active

    fun start(sessionId: Int) {
        stop()
        if (sessionId == 0) return
        try {
            val captureRange = Visualizer.getCaptureSizeRange()
            val captureSize = captureRange[1].coerceAtMost(512).coerceAtLeast(captureRange[0])
            val v = Visualizer(sessionId)
            v.setCaptureSize(captureSize)

            val rate = Visualizer.getMaxCaptureRate().coerceAtMost(20_000) // ~20fps, in milliHz
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(visualizer: Visualizer?, waveform: ByteArray?, samplingRate: Int) {
                    waveform ?: return
                    _levels.value = bucketize(waveform)
                }

                override fun onFftDataCapture(visualizer: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                    // Not used — the waveform capture above is enough for the ring.
                }
            }, rate, /* waveform = */ true, /* fft = */ false)

            v.setEnabled(true)
            visualizer = v
            _active.value = true
        } catch (e: Exception) {
            // Missing RECORD_AUDIO permission, no Visualizer HAL on this device,
            // or the session isn't valid yet — just stay inactive.
            visualizer = null
            _active.value = false
        }
    }

    fun stop() {
        try { visualizer?.setEnabled(false) } catch (e: Exception) { /* ignore */ }
        try { visualizer?.release() } catch (e: Exception) { /* ignore */ }
        visualizer = null
        _active.value = false
        _levels.value = FloatArray(bucketCount)
    }

    /**
     * Waveform bytes are unsigned 8-bit PCM centered at 128 (silence). We
     * split the buffer into [bucketCount] chunks and take the average
     * absolute deviation from center in each chunk as that bucket's level,
     * normalized to 0f..1f.
     */
    private fun bucketize(waveform: ByteArray): FloatArray {
        val result = FloatArray(bucketCount)
        val chunkSize = (waveform.size / bucketCount).coerceAtLeast(1)
        for (i in 0 until bucketCount) {
            val start = i * chunkSize
            val end = (start + chunkSize).coerceAtMost(waveform.size)
            if (start >= end) {
                result[i] = 0f
                continue
            }
            var sum = 0f
            for (j in start until end) {
                val sample = (waveform[j].toInt() and 0xFF) - 128
                sum += kotlin.math.abs(sample)
            }
            val avg = sum / (end - start)
            result[i] = (avg / 128f).coerceIn(0f, 1f)
        }
        return result
    }
}
