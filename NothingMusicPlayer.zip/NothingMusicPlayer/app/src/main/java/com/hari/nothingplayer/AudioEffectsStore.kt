package com.hari.nothingplayer

import android.content.Context

/**
 * Persists audio effect settings (SharedPreferences, like the other *Store
 * objects in this app) so the equalizer/bass boost/virtualizer/loudness
 * settings survive app restarts and carry over between tracks — Android
 * audio effects are tied to a session id and get recreated whenever that
 * session changes, so without this they'd silently reset to flat/off every
 * time playback restarts.
 */
object AudioEffectsStore {

    private const val PREFS = "audio_effects_prefs"
    private const val KEY_ENABLED = "effects_enabled"
    private const val KEY_PRESET = "eq_preset"
    private const val KEY_BAND_LEVELS = "eq_band_levels" // comma-separated millibels
    private const val KEY_BASS_BOOST = "bass_boost_strength"
    private const val KEY_VIRTUALIZER = "virtualizer_strength"
    private const val KEY_LOUDNESS = "loudness_gain_mb"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_ENABLED, true)

    fun setEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    fun eqPreset(context: Context): Int =
        prefs(context).getInt(KEY_PRESET, -1)

    fun setEqPreset(context: Context, preset: Int) {
        prefs(context).edit().putInt(KEY_PRESET, preset).apply()
    }

    /** Returns saved per-band levels (millibels), or null if none saved yet. */
    fun eqBandLevels(context: Context): List<Int>? {
        val raw = prefs(context).getString(KEY_BAND_LEVELS, null) ?: return null
        return raw.split(",").mapNotNull { it.toIntOrNull() }.takeIf { it.isNotEmpty() }
    }

    fun setEqBandLevels(context: Context, levels: List<Int>) {
        prefs(context).edit().putString(KEY_BAND_LEVELS, levels.joinToString(",")).apply()
    }

    fun bassBoostStrength(context: Context): Int =
        prefs(context).getInt(KEY_BASS_BOOST, 0)

    fun setBassBoostStrength(context: Context, strength: Int) {
        prefs(context).edit().putInt(KEY_BASS_BOOST, strength).apply()
    }

    fun virtualizerStrength(context: Context): Int =
        prefs(context).getInt(KEY_VIRTUALIZER, 0)

    fun setVirtualizerStrength(context: Context, strength: Int) {
        prefs(context).edit().putInt(KEY_VIRTUALIZER, strength).apply()
    }

    fun loudnessGainMb(context: Context): Int =
        prefs(context).getInt(KEY_LOUDNESS, 0)

    fun setLoudnessGainMb(context: Context, gainMb: Int) {
        prefs(context).edit().putInt(KEY_LOUDNESS, gainMb).apply()
    }
}
